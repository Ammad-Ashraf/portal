
# Order Status

Order Status

## Enumeration

`OrderStatus`

## Fields

| Name |
|  --- |
| `Placed` |
| `Approved` |
| `Delivered` |

## Example

```
approved
```

