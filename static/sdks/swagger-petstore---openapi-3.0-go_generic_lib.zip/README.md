
# Getting Started with Swagger Petstore - OpenAPI 3.0

## Introduction

This is a sample Pet Store Server based on the OpenAPI 3.0 specification.  You can find out more about
Swagger at [https://swagger.io](https://swagger.io). In the third iteration of the pet store, we've switched to the design first approach!
You can now help us improve the API whether it's by making changes to the definition itself or to the code.
That way, with time, we can improve the API in general, and expose some of the new features in OAS3.

Some useful links:

- [The Pet Store repository](https://github.com/swagger-api/swagger-petstore)
- [The source API definition for the Pet Store](https://github.com/swagger-api/swagger-petstore/blob/master/src/main/resources/openapi.yaml)

Find out more about Swagger: [https://swagger.io](https://swagger.io)

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the swaggerPetstoreOpenApi30 library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace swaggerPetstoreOpenApi30 => ".\\swagger-petstore---openapi-3.0-go_generic_lib" // local path to the SDK

require swaggerPetstoreOpenApi30 v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| petstoreAuthCredentials | [`PetstoreAuthCredentials`](doc/auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |
| apiKeyCredentials | [`ApiKeyCredentials`](doc/auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "swaggerPetstoreOpenApi30"
    "swaggerPetstoreOpenApi30/models"
)

func main() {
    client := swaggerPetstoreOpenApi30.NewClient(
    swaggerPetstoreOpenApi30.CreateConfiguration(
            swaggerPetstoreOpenApi30.WithHttpConfiguration(
                swaggerPetstoreOpenApi30.CreateHttpConfiguration(
                    swaggerPetstoreOpenApi30.WithTimeout(30),
                ),
            ),
            swaggerPetstoreOpenApi30.WithEnvironment(swaggerPetstoreOpenApi30.PRODUCTION),
            swaggerPetstoreOpenApi30.WithPetstoreAuthCredentials(
                swaggerPetstoreOpenApi30.NewPetstoreAuthCredentials(
                    "OAuthClientId",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopePetstoreAuth{
        models.OauthScopePetstoreAuth_Writepets,
        models.OauthScopePetstoreAuth_Readpets,
    }),
            ),
            swaggerPetstoreOpenApi30.WithApiKeyCredentials(
                swaggerPetstoreOpenApi30.NewApiKeyCredentials("api_key"),
            ),
            swaggerPetstoreOpenApi30.WithLoggerConfiguration(
                swaggerPetstoreOpenApi30.WithLevel("info"),
                swaggerPetstoreOpenApi30.WithRequestConfiguration(
                    swaggerPetstoreOpenApi30.WithRequestBody(true),
                ),
                swaggerPetstoreOpenApi30.WithResponseConfiguration(
                    swaggerPetstoreOpenApi30.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`petstore_auth (OAuth 2 Implicit Grant)`](doc/auth/oauth-2-implicit-grant.md)
* [`api_key (Custom Header Signature)`](doc/auth/custom-header-signature.md)

## List of APIs

* [Pet](doc/controllers/pet.md)
* [Store](doc/controllers/store.md)
* [User](doc/controllers/user.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

