
# Oauth Scope Petstore Auth

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopePetstoreAuth`

## Fields

| Name | Description |
|  --- | --- |
| `Writepets` | modify pets in your account |
| `Readpets` | read your pets |

