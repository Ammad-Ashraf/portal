
# Custom Header Signature



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| apiKey | `string` | - | `WithApiKey` | `ApiKey()` |



**Note:** Required auth credentials can be set using `WithApiKeyCredentials()` by providing a credentials instance with `NewApiKeyCredentials()` in the configuration initialization and accessed using the `ApiKeyCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
package main

import (
    "swaggerPetstoreOpenApi30"
)

func main() {
    client := swaggerPetstoreOpenApi30.NewClient(
    swaggerPetstoreOpenApi30.CreateConfiguration(
            swaggerPetstoreOpenApi30.WithApiKeyCredentials(
                swaggerPetstoreOpenApi30.NewApiKeyCredentials("api_key"),
            ),
        ),
    )
}
```


