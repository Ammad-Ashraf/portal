
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| petstoreAuthCredentials | [`PetstoreAuthCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |
| apiKeyCredentials | [`ApiKeyCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "swaggerPetstoreOpenApi30"
    "swaggerPetstoreOpenApi30/models"
)

func main() {
    client := swaggerPetstoreOpenApi30.NewClient(
    swaggerPetstoreOpenApi30.CreateConfiguration(
            swaggerPetstoreOpenApi30.WithHttpConfiguration(
                swaggerPetstoreOpenApi30.CreateHttpConfiguration(
                    swaggerPetstoreOpenApi30.WithTimeout(30),
                ),
            ),
            swaggerPetstoreOpenApi30.WithEnvironment(swaggerPetstoreOpenApi30.PRODUCTION),
            swaggerPetstoreOpenApi30.WithPetstoreAuthCredentials(
                swaggerPetstoreOpenApi30.NewPetstoreAuthCredentials(
                    "OAuthClientId",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopePetstoreAuth{
        models.OauthScopePetstoreAuth_Writepets,
        models.OauthScopePetstoreAuth_Readpets,
    }),
            ),
            swaggerPetstoreOpenApi30.WithApiKeyCredentials(
                swaggerPetstoreOpenApi30.NewApiKeyCredentials("api_key"),
            ),
            swaggerPetstoreOpenApi30.WithLoggerConfiguration(
                swaggerPetstoreOpenApi30.WithLevel("info"),
                swaggerPetstoreOpenApi30.WithRequestConfiguration(
                    swaggerPetstoreOpenApi30.WithRequestBody(true),
                ),
                swaggerPetstoreOpenApi30.WithResponseConfiguration(
                    swaggerPetstoreOpenApi30.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Swagger Petstore - OpenAPI 3.0 Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| PetApi() | Gets PetApi |
| StoreApi() | Gets StoreApi |
| UserApi() | Gets UserApi |

