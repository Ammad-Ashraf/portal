# Pet

Everything about your Pets

Find out more: [https://swagger.io](https://swagger.io)

```go
petApi := client.PetApi()
```

## Class Name

`PetApi`

## Methods

* [Update Pet](../../doc/controllers/pet.md#update-pet)
* [Add Pet](../../doc/controllers/pet.md#add-pet)
* [Find Pets by Status](../../doc/controllers/pet.md#find-pets-by-status)
* [Find Pets by Tags](../../doc/controllers/pet.md#find-pets-by-tags)
* [Get Pet by Id](../../doc/controllers/pet.md#get-pet-by-id)
* [Update Pet With Form](../../doc/controllers/pet.md#update-pet-with-form)
* [Delete Pet](../../doc/controllers/pet.md#delete-pet)
* [Upload File](../../doc/controllers/pet.md#upload-file)


# Update Pet

Update an existing pet by Id.

```go
UpdatePet(
    ctx context.Context,
    name string,
    photoUrls []string,
    id *int64,
    category *models.Category,
    tags []models.Tag,
    status *models.PetStatus) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Form, Required | - |
| `photoUrls` | `[]string` | Form, Required | - |
| `id` | `*int64` | Form, Optional | - |
| `category` | [`*models.Category`](../../doc/models/category.md) | Form, Optional | - |
| `tags` | [`[]models.Tag`](../../doc/models/tag.md) | Form, Optional | - |
| `status` | [`*models.PetStatus`](../../doc/models/pet-status.md) | Form, Optional | pet status in the store |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

name := "doggie"

photoUrls := []string{
    "photoUrls5",
    "photoUrls6",
    "photoUrls7",
}

id := int64(10)

tags := []models.Tag{
    models.Tag{
    },
}

apiResponse, err := petApi.UpdatePet(ctx, name, photoUrls, &id, nil, tags, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Pet not found | `ApiError` |
| 422 | Validation exception | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Add Pet

Add a new pet to the store.

```go
AddPet(
    ctx context.Context,
    name string,
    photoUrls []string,
    id *int64,
    category *models.Category,
    tags []models.Tag,
    status *models.PetStatus) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Form, Required | - |
| `photoUrls` | `[]string` | Form, Required | - |
| `id` | `*int64` | Form, Optional | - |
| `category` | [`*models.Category`](../../doc/models/category.md) | Form, Optional | - |
| `tags` | [`[]models.Tag`](../../doc/models/tag.md) | Form, Optional | - |
| `status` | [`*models.PetStatus`](../../doc/models/pet-status.md) | Form, Optional | pet status in the store |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

name := "doggie"

photoUrls := []string{
    "photoUrls5",
    "photoUrls6",
    "photoUrls7",
}

id := int64(10)

tags := []models.Tag{
    models.Tag{
    },
}

apiResponse, err := petApi.AddPet(ctx, name, photoUrls, &id, nil, tags, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid input | `ApiError` |
| 422 | Validation exception | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Find Pets by Status

Multiple status values can be provided with comma separated strings.

```go
FindPetsByStatus(
    ctx context.Context,
    status *models.PetStatus) (
    models.ApiResponse[[]models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`*models.PetStatus`](../../doc/models/pet-status.md) | Query, Optional | Status values that need to be considered for filter |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := petApi.FindPetsByStatus(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid status value | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Find Pets by Tags

Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.

```go
FindPetsByTags(
    ctx context.Context,
    tags []string) (
    models.ApiResponse[[]models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `[]string` | Query, Optional | Tags to filter by |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := petApi.FindPetsByTags(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid tag value | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Get Pet by Id

Returns a single pet.

```go
GetPetById(
    ctx context.Context,
    petId int64) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet to return |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

petId := int64(10)

apiResponse, err := petApi.GetPetById(ctx, petId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Pet not found | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Update Pet With Form

Updates a pet resource based on the form data.

```go
UpdatePetWithForm(
    ctx context.Context,
    petId int64,
    name *string,
    status *string) (
    models.ApiResponse[models.Pet],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet that needs to be updated |
| `name` | `*string` | Query, Optional | Name of pet that needs to be updated |
| `status` | `*string` | Query, Optional | Status of pet that needs to be updated |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Pet](../../doc/models/pet.md).

## Example Usage

```go
ctx := context.Background()

petId := int64(10)

apiResponse, err := petApi.UpdatePetWithForm(ctx, petId, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid input | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Delete Pet

Delete a pet.

```go
DeletePet(
    ctx context.Context,
    petId int64,
    apiKey *string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | Pet id to delete |
| `apiKey` | `*string` | Header, Optional | - |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

petId := int64(10)

resp, err := petApi.DeletePet(ctx, petId, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid pet value | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Upload File

Upload image of the pet.

```go
UploadFile(
    ctx context.Context,
    petId int64,
    additionalMetadata *string,
    body *models.FileWrapper) (
    models.ApiResponse[models.MApiResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `petId` | `int64` | Template, Required | ID of pet to update |
| `additionalMetadata` | `*string` | Query, Optional | Additional Metadata |
| `body` | `*models.FileWrapper` | Form, Optional | - |

## Requires scope

### petstore_auth

`read:pets`, `write:pets`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.MApiResponse](../../doc/models/m-api-response.md).

## Example Usage

```go
ctx := context.Background()

petId := int64(10)

apiResponse, err := petApi.UploadFile(ctx, petId, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | No file uploaded | `ApiError` |
| 404 | Pet not found | `ApiError` |
| Default | Unexpected error | `ApiError` |

