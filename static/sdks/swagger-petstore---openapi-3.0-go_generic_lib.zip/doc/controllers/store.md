# Store

Access to Petstore orders

Find out more about our store: [https://swagger.io](https://swagger.io)

```go
storeApi := client.StoreApi()
```

## Class Name

`StoreApi`

## Methods

* [Get Inventory](../../doc/controllers/store.md#get-inventory)
* [Place Order](../../doc/controllers/store.md#place-order)
* [Get Order by Id](../../doc/controllers/store.md#get-order-by-id)
* [Delete Order](../../doc/controllers/store.md#delete-order)


# Get Inventory

Returns a map of status codes to quantities.

```go
GetInventory(
    ctx context.Context) (
    models.ApiResponse[map[string]int],
    error)
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type map[string]int.

## Example Usage

```go
ctx := context.Background()

apiResponse, err := storeApi.GetInventory(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Unexpected error | `ApiError` |


# Place Order

Place a new order in the store.

:information_source: **Note** This endpoint does not require authentication.

```go
PlaceOrder(
    ctx context.Context,
    id *int64,
    petId *int64,
    quantity *int,
    shipDate *time.Time,
    status *models.OrderStatus,
    complete *bool) (
    models.ApiResponse[models.Order],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `*int64` | Form, Optional | - |
| `petId` | `*int64` | Form, Optional | - |
| `quantity` | `*int` | Form, Optional | - |
| `shipDate` | `*time.Time` | Form, Optional | - |
| `status` | [`*models.OrderStatus`](../../doc/models/order-status.md) | Form, Optional | Order Status |
| `complete` | `*bool` | Form, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Order](../../doc/models/order.md).

## Example Usage

```go
ctx := context.Background()

id := int64(10)

petId := int64(198772)

quantity := 7

apiResponse, err := storeApi.PlaceOrder(ctx, &id, &petId, &quantity, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid input | `ApiError` |
| 422 | Validation exception | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Get Order by Id

For valid response try integer IDs with value <= 5 or > 10. Other values will generate exceptions.

:information_source: **Note** This endpoint does not require authentication.

```go
GetOrderById(
    ctx context.Context,
    orderId int64) (
    models.ApiResponse[models.Order],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderId` | `int64` | Template, Required | ID of order that needs to be fetched |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Order](../../doc/models/order.md).

## Example Usage

```go
ctx := context.Background()

orderId := int64(62)

apiResponse, err := storeApi.GetOrderById(ctx, orderId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Order not found | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Delete Order

For valid response try integer IDs with value < 1000. Anything above 1000 or non-integers will generate API errors.

:information_source: **Note** This endpoint does not require authentication.

```go
DeleteOrder(
    ctx context.Context,
    orderId int64) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `orderId` | `int64` | Template, Required | ID of the order that needs to be deleted |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

orderId := int64(62)

resp, err := storeApi.DeleteOrder(ctx, orderId)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid ID supplied | `ApiError` |
| 404 | Order not found | `ApiError` |
| Default | Unexpected error | `ApiError` |

