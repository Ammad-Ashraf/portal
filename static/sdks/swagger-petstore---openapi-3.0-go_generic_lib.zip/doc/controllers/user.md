# User

Operations about user

```go
userApi := client.UserApi()
```

## Class Name

`UserApi`

## Methods

* [Create User](../../doc/controllers/user.md#create-user)
* [Create Users With List Input](../../doc/controllers/user.md#create-users-with-list-input)
* [Login User](../../doc/controllers/user.md#login-user)
* [Logout User](../../doc/controllers/user.md#logout-user)
* [Get User by Name](../../doc/controllers/user.md#get-user-by-name)
* [Update User](../../doc/controllers/user.md#update-user)
* [Delete User](../../doc/controllers/user.md#delete-user)


# Create User

This can only be done by the logged in user.

:information_source: **Note** This endpoint does not require authentication.

```go
CreateUser(
    ctx context.Context,
    id *int64,
    username *string,
    firstName *string,
    lastName *string,
    email *string,
    password *string,
    phone *string,
    userStatus *int) (
    models.ApiResponse[models.User],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `*int64` | Form, Optional | - |
| `username` | `*string` | Form, Optional | - |
| `firstName` | `*string` | Form, Optional | - |
| `lastName` | `*string` | Form, Optional | - |
| `email` | `*string` | Form, Optional | - |
| `password` | `*string` | Form, Optional | - |
| `phone` | `*string` | Form, Optional | - |
| `userStatus` | `*int` | Form, Optional | User Status |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.User](../../doc/models/user.md).

## Example Usage

```go
ctx := context.Background()

id := int64(10)

username := "theUser"

firstName := "John"

lastName := "James"

email := "john@email.com"

password := "12345"

phone := "12345"

userStatus := 1

apiResponse, err := userApi.CreateUser(ctx, &id, &username, &firstName, &lastName, &email, &password, &phone, &userStatus)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Unexpected error | `ApiError` |


# Create Users With List Input

Creates list of users with given input array.

:information_source: **Note** This endpoint does not require authentication.

```go
CreateUsersWithListInput(
    ctx context.Context,
    body []models.User) (
    models.ApiResponse[models.User],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`[]models.User`](../../doc/models/user.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.User](../../doc/models/user.md).

## Example Usage

```go
ctx := context.Background()

body := []models.User{
    models.User{
    },
}

apiResponse, err := userApi.CreateUsersWithListInput(ctx, body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Unexpected error | `ApiError` |


# Login User

Log into the system.

:information_source: **Note** This endpoint does not require authentication.

```go
LoginUser(
    ctx context.Context,
    username *string,
    password *string) (
    models.ApiResponse[string],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `*string` | Query, Optional | The user name for login |
| `password` | `*string` | Query, Optional | The password for login in clear text |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type string.

## Example Usage

```go
ctx := context.Background()

apiResponse, err := userApi.LoginUser(ctx, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid username/password supplied | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Logout User

Log user out of the system.

:information_source: **Note** This endpoint does not require authentication.

```go
LogoutUser(
    ctx context.Context) (
    http.Response,
    error)
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

resp, err := userApi.LogoutUser(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Unexpected error | `ApiError` |


# Get User by Name

Get user detail based on username.

:information_source: **Note** This endpoint does not require authentication.

```go
GetUserByName(
    ctx context.Context,
    usersname string) (
    models.ApiResponse[models.User],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `usersname` | `string` | Template, Required | The username that needs to be processed |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.User](../../doc/models/user.md).

## Example Usage

```go
ctx := context.Background()

usersname := "usersname0"

apiResponse, err := userApi.GetUserByName(ctx, usersname)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid username supplied | `ApiError` |
| 404 | User not found | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Update User

This can only be done by the logged in user.

:information_source: **Note** This endpoint does not require authentication.

```go
UpdateUser(
    ctx context.Context,
    usersname string,
    id *int64,
    username *string,
    firstName *string,
    lastName *string,
    email *string,
    password *string,
    phone *string,
    userStatus *int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `usersname` | `string` | Template, Required | The username that needs to be processed |
| `id` | `*int64` | Form, Optional | - |
| `username` | `*string` | Form, Optional | - |
| `firstName` | `*string` | Form, Optional | - |
| `lastName` | `*string` | Form, Optional | - |
| `email` | `*string` | Form, Optional | - |
| `password` | `*string` | Form, Optional | - |
| `phone` | `*string` | Form, Optional | - |
| `userStatus` | `*int` | Form, Optional | User Status |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

usersname := "usersname0"

id := int64(10)

username := "theUser"

firstName := "John"

lastName := "James"

email := "john@email.com"

password := "12345"

phone := "12345"

userStatus := 1

resp, err := userApi.UpdateUser(ctx, usersname, &id, &username, &firstName, &lastName, &email, &password, &phone, &userStatus)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | bad request | `ApiError` |
| 404 | user not found | `ApiError` |
| Default | Unexpected error | `ApiError` |


# Delete User

This can only be done by the logged in user.

:information_source: **Note** This endpoint does not require authentication.

```go
DeleteUser(
    ctx context.Context,
    usersname string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `usersname` | `string` | Template, Required | The username that needs to be processed |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

usersname := "usersname0"

resp, err := userApi.DeleteUser(ctx, usersname)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid username supplied | `ApiError` |
| 404 | User not found | `ApiError` |
| Default | Unexpected error | `ApiError` |

