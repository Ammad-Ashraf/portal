__all__ = [
    'api_exception',
    'oauth_provider_exception',
]
