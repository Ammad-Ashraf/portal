
# Pet Status

pet status in the store

## Enumeration

`PetStatus`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `PENDING` |
| `SOLD` |

