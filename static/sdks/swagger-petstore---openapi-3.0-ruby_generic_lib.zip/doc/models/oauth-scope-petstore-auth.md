
# Oauth Scope Petstore Auth

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopePetstoreAuth`

## Fields

| Name | Description |
|  --- | --- |
| `WRITEPETS` | modify pets in your account |
| `READPETS` | read your pets |

