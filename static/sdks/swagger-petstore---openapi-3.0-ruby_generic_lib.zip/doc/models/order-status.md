
# Order Status

Order Status

## Enumeration

`OrderStatus`

## Fields

| Name |
|  --- |
| `PLACED` |
| `APPROVED` |
| `DELIVERED` |

## Example

```
approved
```

